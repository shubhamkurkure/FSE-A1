export interface JoinRoomResponse {
  coveyUserID: string,
  coveySessionToken: string,
  providerVideoToken: string,
  providerRoomID: string
}
